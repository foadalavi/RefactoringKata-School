﻿namespace School
{
    internal class Program
    {
        public static void Main()
        {
            var app = new StartUp();
            app.Execute();
        }
    }
}
